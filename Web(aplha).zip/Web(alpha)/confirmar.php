<!DOCTYPE html>
<html lang="en">

<head>
    <title>Travels Agency</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width" , initial-scale=1.0>
    <link rel="stylesheet" href="css/estilos.css">
    <link rel="stylesheet" href="css/xml.css">
    <link rel="icon" href="./img/favicon.png" type="image/png" />
 
</head>

<body style="margin: 20%;">
    <h2 class="logotipo4" style="text-align: center;">Comanda realitzada correctament</h2>
    <br /><br />
    <a href="productes.php" style="margin-left: 38%; text-decoration: none;" onclick="javascript:window.localStorage.clear()" class="boto-cistella">Tornar a la pàgina productes</a>
    <br /><br />
</body>
</html>
