<?php
$servername = "localhost";
$username = "root";
$password = "12112017";
$dbname = "database";

// Crear connexió
$conn = new mysqli($servername, $username, $password, $dbname);
// Comprovar connexió
if ($conn->connect_error) {
  die("Error de connexió: " . $conn->connect_error);
}

$sql = "INSERT INTO comandes (id_client, lname, fname, productes, data_comanda) VALUES ('4', 'Oriol', 'Pont', '35', '2021-03-24 17:29:25')";

if ($conn->query($sql) === TRUE) {
  echo "Comanda realitzada correctament.";
  header("location: confirmar.php");
} else {
  echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>