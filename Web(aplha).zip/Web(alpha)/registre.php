<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width" , initial-scale=1.0>
    <link rel="stylesheet" href="css/estilos.css">
    
    <title>TravelsAgency</title>
</head>

<body>
    <header>
        <div class="contenedor">
            <h2 class="logotipo">TravelsAgency</h2>
            <nav>
            <a href="index.php">Inici</a>
                <a href="productes.php">Vols</a>
                <a href="hotels.php">Hotels</a>
                <a href="restaurants.php">Restaurants</a>
                <a href="registre.php">Accés</a>
                <?php 
                session_start();
                    if($_SESSION['login_user']==true){ 
                        echo '<span style="color: #aaa; font-family: sumberjaya;">Benvingut: </span>';
                        echo "<span style='color:red; font-family: sumberjaya;'>" . $_SESSION["login_user"] . "</span>";
                        echo '<a href="logout.php" >  Sortir</a>';
                        }
                ?>
            </nav>
        </div>
    </header>
    <main>
        <div class="destino-principal">
            <div class="contenedor">
                <h3 class="titulo">El Món</h3>
                <p class="descripcion">
                    Comença un nou any i amb ell centenars de plans que et portaran a conèixer nous racons del món. Sabem que ganes no et falten però, desde TravelsAgency, el teu especialista en assegurances de viatge, et donarem l'empenta final amb aquests destins que faran que comencis ja a fer les maletes.
                </p>
                <button role="button" class="boton"><i class="fas fa-play"></i><a href="registre.php">Entrar</a></button>
                <button role="button" class="boton"><i class="fas fa-info"></i>Més informació</button>
            </div>
        </div>
    </main>
    <div class="row">
        <div class="col-xs-12 col-lg-4" style="margin-right: 30px; border-left: 4px solid red; padding-left: 18px;">
        <span class="text-pla">Registra't per obtenir descomptes excusius per clients i rebre les últimes notícies de la nostra web, o bé si ja ets client accedeix des d'aqui.</span>
        </div>
        <div class="col-xs-12 col-lg-4" style="margin-right: 30px;">
            <div id="signup">
            <div id="signup-st">
            <?php
            $remarks = isset($_GET['remarks']) ? $_GET['remarks'] : '';
                if ($remarks==null and $remarks=="") {
                echo ' <div id="reg-head" class="headrg">Registreu-vos aqui</div> ';
                }
                if ($remarks=='success') {
                echo ' <div id="reg-head" class="headrg">Registrat amb èxit</div> ';
                }
                if ($remarks=='failed') {
                echo ' <div id="reg-head-fail" class="headrg">Registre incorrecte, Aquest usuari ja existeix</div> ';
                }
                if ($remarks=='error') {
                echo ' <div id="reg-head-fail" class="headrg">Registre erroni! <br> Error: '.$_GET['value'].' </div> ';
                }
            ?>
            </div>
        <form name="reg" action="execute.php" onsubmit="return validateForm()" method="post" id="reg">
        <table  cellpadding="2" cellspacing="0">
        <tr>
        <td class="t-1">
        <div id="tb-name">Nom:</div>
        </td>
        <td>
        <input type="text" name="fname" id="tb-box" required/>
        </td>
        </tr>
        <tr>
        <td class="t-1"><div id="tb-name">Cognom:</div></td>
        <td><input type="text" name="lname" id="tb-box" required/></td>
        </tr>
        <tr>
        <td class="t-1"><div id="tb-name">Email:</div></td>
        <td><input type="text" id="tb-box" name="address" required/></td>
        </tr>
        <tr>
        <td class="t-1"><div id="tb-name">Usuari:</div></td>
        <td><input type="text" id="tb-box" name="username" required/></td>
        </tr>
        <tr>
        <td class="t-1"><div id="tb-name">Contrasenya:</div></td>
        <td><input id="tb-box" type="password" name="password" required/></td>
        </tr>
        <tr>
        <td class="t-1"><div id="tb-name">IBAN:</div></td>
        <td><input id="tb-box" type="text" name="iban" required/></td>
        </tr>
        </table>
        <div id="st"><input name="submit" type="submit" value="REGISTRAR-ME" id="st-btn"/></div>
        </form>
        
        </div></div>
        <br /><br />
        <div class="col-xs-12 col-lg-4"  style="margin-right: 30px;">
        <div id="login">
        <div id="login-st">
        <form action="logincheck.php" method="POST" id="signin" id="reg">
        <?
                echo "Hello" .$_SESSION['username'];
                ?>
        <?php
        $remarks = isset($_GET['remark_login']) ? $_GET['remark_login'] : '';
        if ($remarks==null and $remarks=="") {
        echo ' <div id="reg-head" class="headrg">Accedeix aqui</div> ';
        }
        if ($remarks=='failed') {
        echo ' <div id="reg-head-fail" class="headrg">Accés erroni!, Credencials invàlides</div> ';
        }
        ?>
        <table  cellpadding="2" cellspacing="0">
        <tr id="lg-1">
        <td class="tl-1"><div id="tb-name">Usuari:</div></td>
        <td><input type="text" id="tb-box" name="username" required/></td>
        </tr>
        <tr id="lg-1">
        <td class="tl-1"><div id="tb-name">Contrasenya:</div></td>
        <td><input id="tb-box" type="password" name="password" required/></td>
        </tr>
        </table>
        <div id="st"><input name="submit" type="submit" value="ACCEDIR" id="st-btn"/></div>
        </form>
        
        </div>
        </div>
        </div>
        </div>
        </div>
    <script src="https://kit.fontawesome.com/2c36e9b7b1.js" crossorigin="anonymous"></script>
</body>

</html>
