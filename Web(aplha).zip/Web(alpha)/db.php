<?php 
$mysql_hostname = "localhost";
$mysql_user = "root";
$mysql_password = "12112017";
$mysql_database = "database";
$con = mysqli_connect($mysql_hostname, $mysql_user, $mysql_password, $mysql_database);
?>

