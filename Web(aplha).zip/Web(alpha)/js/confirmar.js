window.addEventListener("load", getValue, false);

function getValue(){
                for (i = 0; i < localStorage.length; i++){
                    if (typeof(Storage) !== "undefined") {
                    // Retrieve
                    document.getElementById("resum").innerHTML =    "<p>"+JSON.parse(localStorage.getItem(localStorage.key(i))).ref+"</p>"+
                                                                    "<p>"+JSON.parse(localStorage.getItem(localStorage.key(i))).nom+"</p>"+
                                                                    "<p>"+JSON.parse(localStorage.getItem(localStorage.key(i))).ciutat+"</p>"+
                                                                    "<p>"+JSON.parse(localStorage.getItem(localStorage.key(i))).preu+" </p>";
                                                                    
                    } else {
                    document.getElementById("resum").innerHTML = "Sorry, your browser does not support Web Storage...";
                    }
                }
}
