window.addEventListener("load", inici2, false);

function inici2(){
    var registre = document.getElementsByClassName("registrar");
    
    for(i=0; i< registre.length; i++){
        registre[i].addEventListener("click", function(e){
            
            e.preventDefault();
            
            nom = e.target.parentElement.getElementsByClassName("dades")[i].getElementsByTagName("h2")[0].textContent;
            
            ciutat = e.target.parentElement.getElementsByClassName("dades")[i].getElementsByTagName("h3")[0].textContent;
            
            preu = e.target.parentElement.getElementsByClassName("dades")[i].getElementsByTagName("p")[0].textContent;
            
            
            grabarDades(nom, ciutat, preu);
 
            
        }, false);
    }
}

function grabarDades(nom, ciutat, preu){

    clau = localStorage.length + 1;

    // Storing data:
    myObj = {
        nom: nom,
        ciutat: ciutat,
        preu: preu
    };



    myJSON = JSON.stringify(myObj);
    localStorage.setItem(clau, myJSON);


}


