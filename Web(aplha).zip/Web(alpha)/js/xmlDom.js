window.addEventListener("load", totes, false);

function totes(){

function inici() {


    var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function () {
        if (this.readyState == 4 && this.status == 200) {
            lecturaXML(this);
        }
    };
    xhttp.open("GET", "./xml/excursions.xml", true);
    xhttp.send();
}



function lecturaXML(xml) {

    var xmlDoc = xml.responseXML;

    var seccio = document.getElementsByTagName("section")[0];

    for (var i = 0; i < xmlDoc.getElementsByTagName("excursio").length; i++) {

        nom = xmlDoc.getElementsByTagName("nom")[i].childNodes[0].nodeValue;

        ciutat = xmlDoc.getElementsByTagName("ciutat")[i].childNodes[0].nodeValue;

        preu = xmlDoc.getElementsByTagName("preu")[i].childNodes[0].nodeValue;

        imatge = xmlDoc.getElementsByTagName("imatge")[i].childNodes[0].nodeValue;






        seccio.innerHTML += "<div class='maleta'>" +
            "<img src= './img/" + imatge + "'alt='imatge'/>" +
            "<div class='dades'>" +
            "<h2>" + nom + "</h2>" +
            "<h3>" + ciutat + "</h3>" +
            "<p>" + preu + "</p>" +
            "</div>" +
            "<span type='submit' name='add_to_cart' style='margin-top:5px;' class='btn btn-success compra'/>Reservar</span>" +
            "</div>";

    }

}

function inici2(){
    var registre = document.getElementsByClassName("registrar");
    
    for(i=0; i< registre.length; i++){
        registre[i].addEventListener("click", function(e){
            
            e.preventDefault();
            
            nom = e.target.parentElement.getElementsByClassName("dades")[i].getElementsByTagName("h2")[0].textContent;
            
            ciutat = e.target.parentElement.getElementsByClassName("dades")[i].getElementsByTagName("h3")[0].textContent;
            
            preu = e.target.parentElement.getElementsByClassName("dades")[i].getElementsByTagName("p")[0].textContent;
            
            
            grabarDades(nom, ciutat, preu);
 
            
        }, false);
    }
}

function grabarDades(nom, ciutat, preu){

    clau = localStorage.length + 1;

    // Storing data:
    myObj = {
        nom: nom,
        ciutat: ciutat,
        preu: preu
    };



    myJSON = JSON.stringify(myObj);
    localStorage.setItem(clau, myJSON);


}
}