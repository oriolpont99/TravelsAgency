<!DOCTYPE html>
<html lang="en">

<head>
    <title>Travels Agency</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width" , initial-scale=1.0>
    <link rel="stylesheet" href="css/estilos.css">
    <link rel="icon" href="./img/favicon.png" type="image/png" />
</head>

<body>
    <header>
        <div class="contenedor">
            <h2 class="logotipo">Travels Agency</h2>
            <nav>
            <a href="index.php">Inici</a>
            <a href="productes.php">Vols</a>
                <a href="hotels.php">Hotels</a>
                <a href="restaurants.php">Restaurants</a>
                <a href="registre.php">Accés</a>
                <?php 
                session_start();
                    if($_SESSION['login_user']==true){ 
                        echo '<span style="color: #aaa; font-family: sumberjaya;">Benvingut: </span>';
                        echo "<span style='color:red; font-family: sumberjaya;'>" . $_SESSION["login_user"] . "</span>";
                        echo '<a href="logout.php" >    Sortir</a>';
                        }
                ?>
            </nav>
        </div>
    </header>
    <main>
        <div class="destino-principal">
            <div class="contenedor">
                <h3 class="titulo">El Món</h3>
                <p class="descripcion">
                    Comença un nou any i amb ell centenars de plans que et portaran a conèixer nous racons del món. Sabem que ganes no et falten però, desde TravelsAgency, el teu especialista en assegurances de viatge, et donarem l'empenta final amb aquests destins que faran que comencis ja a fer les maletes.
                </p>
                <button role="button" class="boton"><i class="fas fa-play"></i><a href="registre.php">Entrar</a></button>
                <button role="button" class="boton"><i class="fas fa-info"></i>Més informació</button>
            </div>
        </div>
    </main>
    <div class="row" style="margin-top: -50px; padding: 0px !important;">
    <div class="col-xs-12 col-md-4">
    <img src="./img/gif-viatge.gif" style="width: 100%;"/>
    </div>
    <div class="col-xs-12 col-md-8" style="padding: 30px !important;">
    <h2 class="logotipo2">TRAVELS AGENCY</h2>
    <br />
    <p class="text-normal">Busques destinació a bon preu per a les teves vacances? Necessites una escapada de cap de setmana? O potser per fi t’has decidit a fer el viatge de la teva vida? Tenim el que busques: <strong style="color: #E50914;">vols, hotels, vacances...</strong>, amb preus actualitzats al minut. Descobreix-los al nostre web de viatges!</p>
    <br />
    <p class="text-normal"><span class="logotipo">Però, que ens caracteritza?</span></p>
    <br />
    <p class="text-normal"><span class="logotipo">1.</span> Els vols al millor preu del mercat</p>
    <p class="text-normal"><span class="logotipo">2.</span> Els restaurants més ben valorats en gastronomia</p>
    <p class="text-normal"><span class="logotipo">3.</span> Les excursions més intrepidants</p>
    <p class="text-normal"><span class="logotipo">4.</span> Els hotels amb 5 estrelles més ben situats</p>
    <p class="text-normal"><span class="logotipo">5.</span> Les millors ofertes del mercat</p>
    <br />
    <p class="text-normal">Si vols estalviar en el teu viatge, no dubtis en donar un cop d'ull a les nostrs ofertes...</p><br /><br />
    <img src="./img/avio-paper.png" style="width: 15%;" /><br />
    <br /><br /><br />
    <a class="boto" href="productes.php" >Veure totes les opcions</a>
    </div>
    </div>
    <script src="https://kit.fontawesome.com/2c36e9b7b1.js" crossorigin="anonymous"></script>
    <script src="js/main.js"></script>
</body>
<footer>Mostafa Labiad & Adrià Melà & Oriol Pont</footer>

</html>
