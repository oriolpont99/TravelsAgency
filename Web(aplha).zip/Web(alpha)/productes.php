<!DOCTYPE html>
<html lang="en">

<head>
    <title>Travels Agency</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width" , initial-scale=1.0>
    <link rel="stylesheet" href="css/estilos.css">
    <link rel="stylesheet" href="css/xml.css">
    <link rel="icon" href="./img/favicon.png" type="image/png" />
    <script src="./js/vols.js"></script>
</head>

<body>
    <header>
        <div class="contenedor">
            <h2 class="logotipo">Travels Agency</h2>
            <nav>
            <a href="index.php">Inici</a>
                <a href="productes.php">Vols</a>
                <a href="hotels.php">Hotels</a>
                <a href="restaurants.php">Restaurants</a>
                <a href="registre.php">Accés</a>
                <?php 
                session_start();
                    if($_SESSION['login_user']==true){ 
                        echo '<span style="color: #aaa; font-family: sumberjaya;">Benvingut: </span>';
                        echo "<span style='color:red; font-family: sumberjaya;'>" . $_SESSION["login_user"] . "</span>";
                        echo '<a href="logout.php" >    Sortir</a>';
                        }
                ?>
            </nav>
        </div>
    </header>
    
    <main>
        <div class="destino-principal">
            <div class="contenedor">
                <h3 class="titulo">El Món</h3>
                <p class="descripcion">
                    Comença un nou any i amb ell centenars de plans que et portaran a conèixer nous racons del món. Sabem que ganes no et falten però, desde TravelsAgency, el teu especialista en assegurances de viatge, et donarem l'empenta final amb aquests destins que faran que comencis ja a fer les maletes.
                </p>
                <button role="button" class="boton"><i class="fas fa-play"></i><a href="registre.php">Entrar</a></button>
                <button role="button" class="boton"><i class="fas fa-info"></i>Més informació</button>
            </div>
        </div>
    </main>
    <button class="boto-cistella" onclick="myFunction()">Mostrar/Ocultar cistella</button>&nbsp;&nbsp;<button class="boto-cistella" onclick="javascript:window.localStorage.clear();">Borrar productes</button>&nbsp;&nbsp; <button class="boto-cistella" onclick="getValue()">Recarregar cistella</button>
    <div id="myDIV">
    <div class="cistella">
    
    </div>
    <button class="boto-cistella4" onclick="javascript:window.localStorage.clear();">Finalitzar comanda</button>
    </div>
    <p class="logotipo3">La teva selecció:</p>
    
    <section>

    </section>
    <section>

    </section>
    <script src="https://kit.fontawesome.com/2c36e9b7b1.js" crossorigin="anonymous"></script>
    <script src="js/main.js"></script>
    <script>

        var producte = document.getElementsByClassName ("registrar");
            for(i=0; i < producte.length; i++){
                producte[i].addEventListener ("click", function (e){
                    nom = e.target.parentElement.getElementsTagName("h2")[0].textContent;
                    ciutat = e.target.parentElement.getElementsTagName("h3")[0].textContent;
                    preu = e.target.parentElement.getElementsTagName("p")[0].textContent;
                });
        }

    </script>
   

    <script>
    function myFunction() {
    var x = document.getElementById("myDIV");
    if (x.style.display === "none") {
        x.style.display = "block";
    } else {
        x.style.display = "none";
    }
    }
    </script>
</body>
<footer>Mostafa Labiad & Adrià Melà & Oriol Pont</footer>

</html>
